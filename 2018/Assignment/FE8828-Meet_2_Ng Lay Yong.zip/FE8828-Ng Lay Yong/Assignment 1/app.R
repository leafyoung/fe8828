library(shiny)
ui<- fluidPage(
  fluidPage(
    navbarPage(title="Freebies",
               tabPanel("About Us",
                        titlePanel("What do we do?"),
                        h4("We are a non-profit organisation
                        dedicated to bringing you the latest
                        promotions and discounts from all over Singapore
                        so that you don't ever have to pay more than you need.
                        We've got you covered.")),
                        mainPanel(
                          img(src = "freebies.jpg")
                        ),
               tabPanel("Latest Promotions",
                        mainPanel(h1("Grab them now before they are gone!")),
                        mainPanel(h2("From 2 Nov 18 to 30 Nov 18")),
                        mainPanel(h4("Get your free Ben and Jerry ice-cream today! For every single scoop, get another single scoop absolutely free! 
                                     Limited time promotion, expiring in",h3(as.Date("2018-11-30")-Sys.Date()),h4("days' time."))),
                        mainPanel(
                          img(src = "benjerryflavours.jpg")
                        ),
                        
                           mainPanel(h2("From 1 Nov 18 to 6 Nov 18")),
                           mainPanel(h4("Buy 1 get 1 free subway. Promo ends on 6 Nov 18! Only available for 6 inch subs and ala-carte orders.
                                        Limited time promotion, expiring in",h3(as.Date("2018-11-6")-Sys.Date()),h4("days' time."))),
                           mainPanel(
                             img(src = "subway.jpg")
                        )
                        ),
               navbarMenu(title="Events",
                          tabPanel("Flea Market",
                                   mainPanel(h4("The Singapore Really, Really Free Flea Market is held every Sunday at Rowell Road.
                                             For more details, visit the following website",a("here",href="https://www.facebook.com/srrfm/")),h4("From Wikipedia: 
                                        The Really, Really Free Market (RRFM) movement is a non-hierarchical collective of individuals 
                                        who form a temporary market based on an alternative gift economy. 
                                        The RRFM movement aims to counteract capitalism in a non-reactionary way. 
                                 It holds as a major goal to build a community based on sharing resources, 
                                          caring for one another and improving the collective lives of all.")),
                                   mainPanel(
                                     img(src = "srrfm.jpg")
                                   )),
                          tabPanel("Free Concerts",
                                   mainPanel(h4("Free Esplanade concerts for the general public are held once a month on a Sunday. 
                                      Esplanade has a mission of keeping the Arts accessible to the general public. A series of free concerts by homegrown music groups offers everyone the opportunity to enjoy musical performances 
                                      in the Concert Hall. Long queues may be expected, so do come early with your loved ones for a wonderfully FREE concert experience like no other.
                                             Check out their webpage",a("here", href="https://www.esplanade.com/festivals-and-series/beautiful-sunday/2018"),
                                             "on upcoming free concerts")),
                                   mainPanel(
                                     img(src = "concerthall.jpg")
                                   )),
                          tabPanel("Free Vouchers",
                                   mainPanel(h4("If you want to get the best deals before you shop, then check out the free coupons and vouchers at this website",
                                   a("here!",href="https://vouchers.todayonline.com/coupons-food-grocery/"),"Because at Freebies, we believe that the best things in life are FREE.",
                                   h5("Do note that some vouchers may have expired on the website. Therefore, do check the reviews to see if the coupon codes are still working!")
                          ))
  )
)
)
))
server<- function(input,output){
}
shinyApp(ui = ui, server = server)
