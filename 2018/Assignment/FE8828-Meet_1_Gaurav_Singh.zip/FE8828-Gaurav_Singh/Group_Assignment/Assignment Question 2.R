library(tidyverse)
library(readxl)
library(ggplot2)
OptionsDataInitial <- read_excel("C:\\Users\\singh\\Desktop\\syllabus\\Mini 3\\FE8828 Programming Web Applications in Finance (E)\\Homework_Assignments\\FE8828-Gaurav_Singh\\Group_Assignment\\Question3_data.xlsx")
Optionsdata<-data.frame(OptionsDataInitial$Date,OptionsDataInitial$Close,OptionsDataInitial$IV30)
Previous_Close<-Optionsdata$OptionsDataInitial.Close
Optionsdata <- na.omit(Optionsdata)
Previous_Close<-na.omit(Previous_Close)
Previous_Close<-tail(Previous_Close,-1)
Optionsdata<-head(Optionsdata,-1)
Optionsdata<-data.frame(Optionsdata,Previous_Close)
names(Optionsdata)[1]="Date"
names(Optionsdata)[2]="Close"
names(Optionsdata)[3]="IV30"
names(Optionsdata)[4]="Previous_Close"
xts_obj<-xts(Optionsdata,order.by=Optionsdata[,1])

#Getting start date and end date

dates <- index(xts_obj)
start_date <- min(dates)
end_date <- max(dates)
start_price <- xts_obj[start_date, "Close"]
start_volatility <- xts_obj[start_date, "IV30"]

#Creating a dataframe with date colmun

df <- tibble(date = dates)
df$Close <- coredata(xts_obj[, "Close"])
df$IV30 <- coredata(xts_obj[, "IV30"])
df$Previous_Close<-coredata(xts_obj[, "Previous_Close"])
#Option Pricing 

X <- start_price
sigma = as.numeric(start_volatility)/100
r <- 0.8 / 100
b=1.73/100
# Vary S and Time everyday
S <- Close
Time1 <-as.numeric((end_date - df$date)/31536000)
quantity=100
#GBSOption(TypeFlag, S, X, Time, r, b, sigma)@price
Strike_Price=148
GBSGreeks("delta", TypeFlag="c", S=as.numeric(df$Previous_Close[1]), X=Strike_Price, Time=30/365, r=0.8/100, b=1.73/100, sigma=sigma)
GBSOption(TypeFlag = "c",
          S = as.numeric(df$Close[1]),
          X =Strike_Price,
          Time =Time1[1],
          r=r,
          b=b,
          sigma=sigma)@price

df_opt <-mutate(df,premium=GBSOption(TypeFlag = "c",
                                                S = as.numeric(Previous_Close),
                                                X =Strike_Price,
                                                Time =Time1,
                                                r=r,
                                                b=b,
                                                sigma=sigma)@price)%>%
  ungroup%>%mutate(Option_DoD_PnL = ifelse(date == start_date,
                                           premium * (-1)*quantity,
                                           (premium*quantity) - lag(premium*quantity)))


df_opt <-mutate(df_opt,delta_hedge = round(GBSGreeks("delta", TypeFlag= "c", S = as.numeric(Previous_Close),  X =Strike_Price, Time=Time1, r=r,
                                               b=b, sigma=as.numeric(IV30[1])/100) *
        quantity * (-1)))
  
df_opt <-mutate(df_opt,Hedging_DoD_Pnl = ifelse(date == start_date,(delta_hedge * (as.numeric(Close) - (as.numeric(Previous_Close)))),(delta_hedge * (as.numeric(Close) - lag(as.numeric(Close))))))
df_opt<-mutate(df_opt,Net_PnL = Option_DoD_PnL + Hedging_DoD_Pnl)

sum(df_opt$Net_PnL)

ggplot(df_opt, aes(x=df_opt$date,y=Option_DoD_PnL )) + 
  geom_line(color="Blue") + 
  geom_line(aes(y=Option_DoD_PnL), linetype="dotted") +
  geom_line(aes(y=Hedging_DoD_Pnl), linetype="dotted") + 
  theme_minimal()




mutate(df_opt,PnL = cumsum(Hedging_DoD_Pnl)) %>%
{
  xs <- .$PnL
  max(cummax(xs) - cummin(xs))
}
View(df_opt)
