library(tidyverse)
library(dplyr)
library(fOptions)
library(lubridate)
library(bizdays)
S <- 100
K <- 100
#Part [1]
sigma <- 0.3 # realized vol can be 0.3 for [1] or 0.5 for [2]
drift <- 0 # drift = r - q
N <- 30
timestep <- 1 / 250
p1 <- (drift - 0.5 * sigma * sigma) * timestep
p2 <- sigma * sqrt(timestep)
# ss is the simulated price movement for N days
ss <- rep(S, N) * cumprod(rlnorm(N, mean = p1, sd = p2))
df <- data_frame(S = ss, days = 1:N)
opt <- df %>%
  rowwise() %>%
  mutate(price = GBSOption("c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3)@price,
          delta = GBSGreeks("Delta", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3),
          gamma = GBSGreeks("Gamma", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3),
          theta = GBSGreeks("Theta", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3)) %>%
  ungroup()

opt1 <- opt %>%
  mutate(stock_price_change = c(0,diff(S)),
         price_change = c(0,diff(price)),
         approx = delta * stock_price_change + 0.5 * gamma * (stock_price_change) ** 2 + theta * 1/250,
         gt_neutralise = 0.5 * gamma * (price_change) ** 2 + theta * 1/250) %>%
  mutate(gt_neutralise = ifelse(gt_neutralise<0.001, 0, gt_neutralise))

#Part [2] - Assuming long call option
sigma <- 0.5
p1 <- (drift - 0.5 * sigma * sigma) * timestep
p2 <- sigma * sqrt(timestep)
# ss is the simulated price movement for N days
ss <- rep(S, N) * cumprod(rlnorm(N, mean = p1, sd = p2))
df1 <- data_frame(S = ss, days = 1:N)

opt2 <- df1 %>%
  rowwise() %>%
  mutate(price = GBSOption("c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3)@price,
         delta = GBSGreeks("Delta", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3),
         gamma = GBSGreeks("Gamma", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3),
         theta = GBSGreeks("Theta", "c", S = S, X = 100, Time = (N+1-days) / 250, r = 0, b = 0, sigma = 0.3)) %>%
  ungroup()
opt3 <- opt2 %>%
  mutate(premium_change = c(0,diff(price)),
         stock_price_change = c(0,diff(S)),
         PnL = ifelse(days==1, -price, premium_change + (-delta)*(stock_price_change)),
         total_PnL = cumsum(PnL))

vega <- GBSGreeks("Vega", "c", S = S, X = K, Time = N / 250, r = 0, b = 0, sigma = 0.3)
PnL_Total <- vega * (sigma - 0.3) * (N/250) - opt2[["price"]][1]        
