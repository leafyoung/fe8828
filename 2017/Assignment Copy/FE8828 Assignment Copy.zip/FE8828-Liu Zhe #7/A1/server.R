#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Author: Liu Zhe
# Matric Number: G1700201C
# Date: 12/11/2017
#
# Introduction:
# This webpage is coded R Shiny, for a virtual "NTU Online Match Making" company
# 
# The overall website is designed in "navBar" layout
# 1st tab: "Our Service", "sideBar" layout
# 2nd tab: "Give Me Your Info", 2-column layout
# 3rd tab: "Meet the Developers", "Navlist" layout
#
# Define server logic required to draw a histogram

server <- function(input, output) {
}
