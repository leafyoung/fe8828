# shiny-51-renderPrint.R
library(shiny)

ui <- fluidPage(
  actionButton('go', 'Go'),
  verbatimTextOutput("t1"),
  verbatimTextOutput("t2"),
)

server <- function(input, output, session) {
  observeEvent(input$go, {
    for (i in 1:10) {
      output$t1 <- renderText({ i })
    }    
  })

  observeEvent(input$go, {
    output$t2 <- renderPrint({ 
      for (i in 1:10) {
        cat(paste0(i, "\n"))
      }
    })
  })  
}

shinyApp(ui, server)