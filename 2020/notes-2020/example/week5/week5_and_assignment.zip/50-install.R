# 50-install.R
install.packages(c("tidyquant", "Quandl","rvest",
                   "dygraphs", "forecast","testit"))